from django.http import HttpResponse
from django.shortcuts import render

def index(request):
    return render(request,'index.html')
# def kaim(request):
#     return HttpResponse("<center><h4>I am so successful and rich</h4></center>")
#
# def kamal(request):
#     return  HttpResponse("<center><h2><i>I am so successful and multibillionaire and I am so confident</i></h2></center>")
#
# def get_back_page(request):
#     return HttpResponse("get back<a href='/'><h3>back</h3></a>")
#
# def ex1(request):
#         s = ''' Navigation Bar <br> </h2>
#         <a href= "https://www.youtube.com/playlist?list=PLu0W_9lII9ah7DDtYtflgwMwpT3xmjXY9" > Django Code With Harry Bhai </a><br>
#         <a href="https://www.facebook.com/"> Facebook </a> <br>
#         <a href="https://www.flipkart.com/"> Flipkart </a> <br>
#         <a href="https://www.hindustantimes.com/"> News </a> <br>
#         <a href="https://www.google.com/"> Google </a> <br>'''
#         return HttpResponse(s)

# def removepunc(request):
#     djtext=request.GET.get('text','default')
#     print(djtext)
#
#     return HttpResponse("remove punc")


def analyze(request):
    djtext=request.GET.get('text','default')
    NewLine_remover= request.GET.get('NewLine_remover','off')
    removepunc = request.GET.get('removepunc','off')
    fullcaps = request.GET.get('fullcaps','off')
    extra_space_remover=request.GET.get('extra_space_remover','off')
    char_count = request.GET.get('char_count','off')

    #check which checkbox is on
    if removepunc =='on':
        punctuations = '''
                            !()-[]{};:'"\,<>./?~!@#$%^&*`
                    '''

        analyzed = ''

        for char in djtext:
            if char not in punctuations:
                 analyzed = analyzed +char
        params = {'purpose':'removed punchtuations',
                      'analyzed_text':analyzed
                      }
        return render(request,'analyze.html',params)

    elif (fullcaps=='on'):
        analyzed=''
        for char in djtext:
            analyzed = analyzed+char.upper()
        params = {'purpose':'change to uppercase','analyzed_text':analyzed}
        return render(request,'analyze.html',params)
    elif (NewLine_remover == 'on'):
        analyzed=''
        for char in djtext:
            if char!='\n':
                analyzed=analyzed+char
        params={'purpose':'Remove  NewLines','analyzed_text':analyzed}

        return render(request,'analyze.html',params)
    elif extra_space_remover=='on':
        analyzed=''
        for  index, char in  enumerate(djtext):
            if not(djtext[index] == ' ' and djtext[index+1]==' '):
                analyzed= analyzed + char
        params = {'purpose':'Remove Newlines','analyzed_text':analyzed}

        return render(request,'analyze.html',params)
    elif char_count=='on':
        analyzed=0
        # counter=0
        for char in djtext:
            analyzed+=1
        params = {'purpose':'counting the character','analyzed_text':analyzed}
        return  render(request,'analyze.html',params)
    else:
        return HttpResponse("Error")

